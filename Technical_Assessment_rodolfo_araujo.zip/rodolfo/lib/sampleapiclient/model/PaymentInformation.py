class PaymentInformation:
    def __init__(self):
        self.card = None

    def set_card(self, value):
        self.card = value
