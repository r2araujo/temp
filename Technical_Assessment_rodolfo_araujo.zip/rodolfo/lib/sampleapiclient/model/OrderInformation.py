class OrderInformation:
    def __init__(self):
        self.billTo = None
        self.amountDetails = None

    def set_bill_to(self, value):
        self.billTo = value

    def set_amount_details(self, value):
        self.amountDetails = value


