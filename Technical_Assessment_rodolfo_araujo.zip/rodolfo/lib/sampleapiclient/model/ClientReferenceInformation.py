class ClientReferenceInformation:
    def __init__(self):
        self.code = None

    def set_code(self, value):
        self.code = value
