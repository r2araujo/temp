class ProcessingInformation:
    def __init__(self):
        self.commerceIndicator = None

    def set_commerce_indicator(self, value):
        self.commerceIndicator = value
