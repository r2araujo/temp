class AmountDetails:
    def __init__(self):
        self.totalAmount = None
        self.currency = None

    def set_total_amount(self, value):
        self.totalAmount = value

    def set_currency(self, value):
        self.currency = value
