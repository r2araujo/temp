import os


class Configuration:
    def __init__(self):
        self.authentication_type ="http_signature"
        self.merchantid = "raraujo"
        self.alternative_merchantid = ""
        self.run_environment = "apitest.cybersource.com"
        self.request_json_path = ""
        # JWT PARAMETERS
        self.key_alias = "raraujo"
        self.key_pass = ""
        self.key_file_name = "raraujo"
        self.alternative_key_alias = ""
        self.alternative_key_pass = ""
        self.alternative_key_file_name = ""
        self.keys_directory = os.path.join(os.getcwd(), "resources")
        # HTTP PARAMETERS
        self.merchant_keyid = "2f4b421f-7ce8-4acb-b5bb-f95221699e4d"
        self.merchant_secretkey = "yeKU10gmROFLn95nPfhJRf7U9bPUqky98gOJ5DRjSpo="
        #self.alternative_merchant_keyid = "e547c3d3-16e4-444c-9313-2a08784b906a"
        #self.alternative_merchant_secretkey = "JXm4dqKYIxWofM1TIbtYY9HuYo7Cg1HPHxn29f6waRo="
        # META KEY PARAMETERS
        self.use_metakey = False
        self.portfolio_id = ''
        # CONNECTION TIMEOUT PARAMETER
        self.timeout = 1000
        # LOG PARAMETERS
        self.enable_log = True
        self.log_file_name = "cybs"
        self.log_maximum_size = 10487560
        self.log_directory = os.path.join(os.getcwd(), "Logs")
        # PROXY PARAMETERS
        #self.proxy_address = "userproxy.com"
        #self.proxy_port = ""

    # Assigning the configuration properties in the configuration dictionary
    def get_configuration(self):
        configuration_dictionary = ({})
        configuration_dictionary["authentication_type"] = self.authentication_type
        configuration_dictionary["merchantid"] = self.merchantid
        configuration_dictionary["run_environment"] = self.run_environment
        configuration_dictionary["request_json_path"] = self.request_json_path
        configuration_dictionary["key_alias"] = self.key_alias
        configuration_dictionary["key_password"] = self.key_pass
        configuration_dictionary["key_file_name"] = self.key_file_name
        configuration_dictionary["keys_directory"] = self.keys_directory
        configuration_dictionary["merchant_keyid"] = self.merchant_keyid
        configuration_dictionary["merchant_secretkey"] = self.merchant_secretkey
        configuration_dictionary["use_metakey"] = self.use_metakey
        configuration_dictionary["portfolio_id"] = self.portfolio_id
        configuration_dictionary["enable_log"] = self.enable_log
        configuration_dictionary["timeout"] = self.timeout
        configuration_dictionary["log_file_name"] = self.log_file_name
        configuration_dictionary["log_maximum_size"] = self.log_maximum_size
        configuration_dictionary["log_directory"] = self.log_directory
        #configuration_dictionary["proxy_address"] = self.proxy_address
        #configuration_dictionary["proxy_port"] = self.proxy_port
        return configuration_dictionary

    def get_alternative_configuration(self):
        configuration_dictionary = ({})
        configuration_dictionary["authentication_type"] = self.authentication_type
        configuration_dictionary["merchantid"] = self.alternative_merchantid
        configuration_dictionary["run_environment"] = self.run_environment
        configuration_dictionary["request_json_path"] = self.request_json_path
        configuration_dictionary["key_alias"] = self.alternative_key_alias
        configuration_dictionary["key_password"] = self.alternative_key_pass
        configuration_dictionary["key_file_name"] = self.alternative_key_file_name
        configuration_dictionary["keys_directory"] = self.keys_directory
        configuration_dictionary["merchant_keyid"] = self.alternative_merchant_keyid
        configuration_dictionary["merchant_secretkey"] = self.alternative_merchant_secretkey
        configuration_dictionary["use_metakey"] = self.use_metakey
        configuration_dictionary["portfolio_id"] = self.portfolio_id
        configuration_dictionary["enable_log"] = self.enable_log
        configuration_dictionary["timeout"] = self.timeout
        configuration_dictionary["log_file_name"] = self.log_file_name
        configuration_dictionary["log_maximum_size"] = self.log_maximum_size
        configuration_dictionary["log_directory"] = self.log_directory
        #configuration_dictionary["proxy_address"] = self.proxy_address
        #configuration_dictionary["proxy_port"] = self.proxy_port
        return configuration_dictionary
