from CyberSource import *
import os
import json
from importlib.machinery import SourceFileLoader

config_file = os.path.join(os.getcwd(), "data", "Configuration.py")
configuration = SourceFileLoader("module.name", config_file).load_module()

# To delete None values in Input Request Json body
def del_none(d):
    for key, value in list(d.items()):
        if value is None:
            del d[key]
        elif isinstance(value, dict):
            del_none(value)
    return d

def authorization_with_capturesale(clientReferenceInformationCode, currency, amount,
                                    paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear,
                                    captureFlag):

    clientReferenceInformation = Ptsv2paymentsClientReferenceInformation(
        code = clientReferenceInformationCode
    )

    
    processingInformationCapture = captureFlag
    processingInformation = Ptsv2paymentsProcessingInformation(
        capture = processingInformationCapture
    )

    
    paymentInformationCard = Ptsv2paymentsPaymentInformationCard(
        number = paymentInformationCardNumber,
        expiration_month = paymentInformationCardExpirationMonth,
        expiration_year = paymentInformationCardExpirationYear
    )

    paymentInformation = Ptsv2paymentsPaymentInformation(
        card = paymentInformationCard.__dict__
    )

    orderInformationAmountDetailsTotalAmount = amount
    orderInformationAmountDetailsCurrency = currency
    orderInformationAmountDetails = Ptsv2paymentsOrderInformationAmountDetails(
        total_amount = orderInformationAmountDetailsTotalAmount,
        currency = orderInformationAmountDetailsCurrency
    )

    orderInformationBillToFirstName = "John"
    orderInformationBillToLastName = "Doe"
    orderInformationBillToAddress1 = "1 Market St"
    orderInformationBillToLocality = "san francisco"
    orderInformationBillToAdministrativeArea = "CA"
    orderInformationBillToPostalCode = "94105"
    orderInformationBillToCountry = "US"
    orderInformationBillToEmail = "test@cybs.com"
    orderInformationBillToPhoneNumber = "4158880000"
    orderInformationBillTo = Ptsv2paymentsOrderInformationBillTo(
        first_name = orderInformationBillToFirstName,
        last_name = orderInformationBillToLastName,
        address1 = orderInformationBillToAddress1,
        locality = orderInformationBillToLocality,
        administrative_area = orderInformationBillToAdministrativeArea,
        postal_code = orderInformationBillToPostalCode,
        country = orderInformationBillToCountry,
        email = orderInformationBillToEmail,
        phone_number = orderInformationBillToPhoneNumber
    )

    orderInformation = Ptsv2paymentsOrderInformation(
        amount_details = orderInformationAmountDetails.__dict__,
        bill_to = orderInformationBillTo.__dict__
    )

    requestObj = CreatePaymentRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        processing_information = processingInformation.__dict__,
        payment_information = paymentInformation.__dict__,
        order_information = orderInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = PaymentsApi(client_config)
        return_data, status, body = api_instance.create_payment(requestObj)

        print("\nAPI PaymentsApi RESPONSE CODE : ", status)
        print("\nAPI PaymentsApi RESPONSE BODY : ", body)

        return return_data
    except Exception as e:
        print("\nException when calling PaymentsApi->create_payment: %s\n" % e)


def capture_payment(paymentId, clientReferenceInformationCode, orderInformationAmountDetailsTotalAmount, orderInformationAmountDetailsCurrency):

    clientReferenceInformation = Ptsv2paymentsClientReferenceInformation(
        code = clientReferenceInformationCode
    )

    orderInformationAmountDetails = Ptsv2paymentsidcapturesOrderInformationAmountDetails(
        total_amount = orderInformationAmountDetailsTotalAmount,
        currency = orderInformationAmountDetailsCurrency
    )

    orderInformation = Ptsv2paymentsidcapturesOrderInformation(
        amount_details = orderInformationAmountDetails.__dict__
    )

    requestObj = CapturePaymentRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        order_information = orderInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = CaptureApi(client_config)
        return_data, status, body = api_instance.capture_payment(requestObj, paymentId)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)

        return return_data
    except Exception as e:
        print("\nException when calling CaptureApi->capture_payment: %s\n" % e)


def process_authorization_reversal(paymentId, clientReferenceInformationCode, amount, reversalInformationReason):
    
    clientReferenceInformation = Ptsv2paymentsidreversalsClientReferenceInformation(
        code = clientReferenceInformationCode
    )

    reversalInformationAmountDetailsTotalAmount = amount
    reversalInformationAmountDetails = Ptsv2paymentsidreversalsReversalInformationAmountDetails(
        total_amount = reversalInformationAmountDetailsTotalAmount
    )

    reversalInformation = Ptsv2paymentsidreversalsReversalInformation(
        amount_details = reversalInformationAmountDetails.__dict__,
        reason = reversalInformationReason
    )

    requestObj = AuthReversalRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        reversal_information = reversalInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = ReversalApi(client_config)
        return_data, status, body = api_instance.auth_reversal(paymentId, requestObj)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)
        print("\n RETURN DATA: ", return_data)

        return return_data
    except Exception as e:
        print("\nException when calling ReversalApi->auth_reversal: %s\n" % e)

def refund_payment(paymentId, amount, currency, clientReferenceInformationCode):
   
    clientReferenceInformation = Ptsv2paymentsClientReferenceInformation(
        code = clientReferenceInformationCode
    )

    orderInformationAmountDetailsTotalAmount = amount
    orderInformationAmountDetailsCurrency = currency
    orderInformationAmountDetails = Ptsv2paymentsidcapturesOrderInformationAmountDetails(
        total_amount = orderInformationAmountDetailsTotalAmount,
        currency = orderInformationAmountDetailsCurrency
    )

    orderInformation = Ptsv2paymentsidrefundsOrderInformation(
        amount_details = orderInformationAmountDetails.__dict__
    )

    requestObj = RefundPaymentRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        order_information = orderInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = RefundApi(client_config)
        return_data, status, body = api_instance.refund_payment(requestObj, paymentId)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)

        return return_data
    except Exception as e:
        print("\nException when calling RefundApi->refund_payment: %s\n" % e)


def add_data_to_list(type):

    orderInformationBillToEmail = "assessment@reject.com.br"

    orderInformationBillTo = Riskv1liststypeentriesOrderInformationBillTo(
        email = orderInformationBillToEmail
    )

    orderInformation = Riskv1liststypeentriesOrderInformation(
        bill_to = orderInformationBillTo.__dict__
    )

    paymentInformation = Riskv1liststypeentriesPaymentInformation(
    )

    clientReferenceInformationCode = "54323007"
    clientReferenceInformationPartnerDeveloperId = "7891234"
    clientReferenceInformationPartnerSolutionId = "89012345"
    clientReferenceInformationPartner = Riskv1decisionsClientReferenceInformationPartner(
        developer_id = clientReferenceInformationPartnerDeveloperId,
        solution_id = clientReferenceInformationPartnerSolutionId
    )

    clientReferenceInformation = Riskv1decisionsClientReferenceInformation(
        code = clientReferenceInformationCode,
        partner = clientReferenceInformationPartner.__dict__
    )

    riskInformationMarkingDetailsAction = "add"
    riskInformationMarkingDetails = Riskv1liststypeentriesRiskInformationMarkingDetails(
        action = riskInformationMarkingDetailsAction
    )

    riskInformation = Riskv1liststypeentriesRiskInformation(
        marking_details = riskInformationMarkingDetails.__dict__
    )

    requestObj = AddNegativeListRequest(
        order_information = orderInformation.__dict__,
        payment_information = paymentInformation.__dict__,
        client_reference_information = clientReferenceInformation.__dict__,
        risk_information = riskInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = DecisionManagerApi(client_config)
        return_data, status, body = api_instance.add_negative(type, requestObj)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)

        return return_data
    except Exception as e:
        print("\nException when calling DecisionManagerApi->add_negative: %s\n" % e)

def basic_dm_transaction(paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear, paymentInformationCardCvv):
    clientReferenceInformationCode = "54323007"
    clientReferenceInformationComments = "decision manager case"
    clientReferenceInformationPartnerDeveloperId = "7891234"
    clientReferenceInformationPartnerSolutionId = "89012345"
    clientReferenceInformationPartner = Riskv1decisionsClientReferenceInformationPartner(
        developer_id = clientReferenceInformationPartnerDeveloperId,
        solution_id = clientReferenceInformationPartnerSolutionId
    )

    clientReferenceInformation = Riskv1decisionsClientReferenceInformation(
        code = clientReferenceInformationCode,
        comments = clientReferenceInformationComments,
        partner = clientReferenceInformationPartner.__dict__
    )

    paymentInformationCard = Riskv1decisionsPaymentInformationCard(
        number = paymentInformationCardNumber,
        expiration_month = paymentInformationCardExpirationMonth,
        expiration_year = paymentInformationCardExpirationYear
    )

    paymentInformation = Riskv1decisionsPaymentInformation(
        card = paymentInformationCard.__dict__
    )

    orderInformationAmountDetailsCurrency = "BRL"
    orderInformationAmountDetailsTotalAmount = "144.14"
    orderInformationAmountDetails = Riskv1decisionsOrderInformationAmountDetails(
        currency = orderInformationAmountDetailsCurrency,
        total_amount = orderInformationAmountDetailsTotalAmount
    )

    orderInformationBillToAddress1 = "96, powers street"
    orderInformationBillToAdministrativeArea = "SP"
    orderInformationBillToCountry = "BR"
    orderInformationBillToLocality = "Clearwater milford"
    orderInformationBillToFirstName = "James"
    orderInformationBillToLastName = "Smith"
    orderInformationBillToPhoneNumber = "7606160717"
    orderInformationBillToEmail = "assessment@reject.com.br"
    orderInformationBillToPostalCode = "05024000"
    orderInformationBillTo = Riskv1decisionsOrderInformationBillTo(
        address1 = orderInformationBillToAddress1,
        administrative_area = orderInformationBillToAdministrativeArea,
        country = orderInformationBillToCountry,
        locality = orderInformationBillToLocality,
        first_name = orderInformationBillToFirstName,
        last_name = orderInformationBillToLastName,
        phone_number = orderInformationBillToPhoneNumber,
        email = orderInformationBillToEmail,
        postal_code = orderInformationBillToPostalCode
    )

    orderInformation = Riskv1decisionsOrderInformation(
        amount_details = orderInformationAmountDetails.__dict__,
        bill_to = orderInformationBillTo.__dict__
    )

    requestObj = CreateBundledDecisionManagerCaseRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        payment_information = paymentInformation.__dict__,
        order_information = orderInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = DecisionManagerApi(client_config)
        return_data, status, body = api_instance.create_bundled_decision_manager_case(requestObj)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)

        return return_data
    except Exception as e:
        print("\nException when calling DecisionManagerApi->create_bundled_decision_manager_case: %s\n" % e)



def exercise1_authorization_and_capture_2_steps(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear):
    api_payment_response = authorization_with_capturesale(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear, False)
    paymentId = api_payment_response.id
    capture_payment(paymentId, clientReferenceInformationCode, amount, currency)
    return

def exercise2_authorization_and_capture_1_step(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear):
    authorization_with_capturesale(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear, True)  
    return

def exercise3_authorization_reversal(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear):
    api_payment_response = authorization_with_capturesale(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear, False)
    paymentId = api_payment_response.id
    reversalInformationReason = 'testing'

    process_authorization_reversal(paymentId, clientReferenceInformationCode, amount, reversalInformationReason)
    return

def exercise4_authorization_credit_refund(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear):
    api_payment_response = authorization_with_capturesale(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear, True)  
    paymentId = api_payment_response.id    

    refund_payment(paymentId, amount, currency, clientReferenceInformationCode)
    return


def exercise5_trigger_decision_manager_rule(paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear):  
    add_data_to_list("negative")
    paymentInformationCardNumber = "4622943127013705"
    paymentInformationCardExpirationMonth = "12"
    paymentInformationCardExpirationYear = "2022"
    paymentInformationCardCvv = "838"
  
    basic_dm_transaction(paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear, paymentInformationCardCvv)
    return

if __name__ == "__main__":

    amount = '103.45'
    currency = 'BRL'
    paymentInformationCardNumber = "4111111111111111"
    paymentInformationCardExpirationMonth = "12"
    paymentInformationCardExpirationYear = "2031"
    clientReferenceInformationCode = "TEST1234_BRLRA"
    
    exercise4_authorization_credit_refund(clientReferenceInformationCode, currency, amount, paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear)
        
    #exercise5_trigger_decision_manager_rule(paymentInformationCardNumber, paymentInformationCardExpirationMonth, paymentInformationCardExpirationYear)
